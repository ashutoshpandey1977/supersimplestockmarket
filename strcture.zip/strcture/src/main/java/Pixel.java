public final class Pixel {
    private final int x;
    private final int y;
    private final int z;
    private final Colour colour;

    public Pixel(int x, int y, int z) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.colour=new Colour(0,0,0,0);
    }
    public Pixel(int x, int y, int z,Colour colour) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.colour=colour;
    }
    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getZ() {
        return z;
    }

    public Colour getColour() {
        return colour;
    }
}
