import java.util.List;

public  abstract class   Block {
    protected final Pixel origin;
    protected final int length;
    protected final int breadth;
    protected final int height;

    public Colour getColour() {
        return colour;
    }

    protected final Colour colour;


    Block(Pixel origin, int length, int breadth, int height, Colour color) {
        this.origin = origin;
        this.length = length;
        this.breadth = breadth;
        this.height = height;
        this.colour = color;
    }
    abstract List<Pixel> getPixels();

}
