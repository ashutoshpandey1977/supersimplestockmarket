import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;

public class Canvas {
    public void draw(Structure structure) throws IOException {
        List<Pixel> s =structure.getPixels((o1, o2) -> {
            if (o1.getZ()==o2.getZ()){
                if (o1.getY()==o2.getY()){
                    return o1.getX()-o2.getX();
                }
                else {
                    return o1.getY()-o2.getY();
                }
            }
            else{
                return o1.getZ()-o2.getZ();
            }
        });
        BufferedImage off_Image =
                new BufferedImage(500, 500,
                        BufferedImage.TYPE_INT_ARGB);

        s.stream().forEach(p->{
            int pc = (255<<p.getColour().getAlpha()) | (100<<p.getColour().getRed()) | (150<<p.getColour().getGreen()) | p.getColour().getBlue();
            off_Image.setRGB(p.getX(),p.getY(),pc);
        });
        File outputfile = new File("saved.png");
        ImageIO.write(off_Image, "png", outputfile);
    }

    public static void main(String[] args) throws IOException {
        Canvas c =new Canvas();
        Random r=new Random();
        Structure structure =new Structure();
        IntStream.range(0,100).forEach(i->structure.add(new Cube(new Pixel(r.nextInt(100),r.nextInt(100),r.nextInt(100)),20,20,20,new Colour(r.nextInt(255),r.nextInt(255),r.nextInt(255),r.nextInt(255)))));
        c.draw(structure);

    }
}
