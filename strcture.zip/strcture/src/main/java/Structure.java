import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Structure {
    List<Block> blockList=new ArrayList<>();
    public void add(Block block){
        blockList.add(block);
    }
    public List<Pixel> getPixels( Comparator<Pixel> comparator){

        List<Pixel> pixels = blockList.stream().map(b -> b.getPixels()).flatMap(List::stream).collect(Collectors.toList());
        pixels.sort(comparator);
        return pixels;
    }

}
