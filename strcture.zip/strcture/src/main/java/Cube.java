import java.util.ArrayList;
import java.util.List;

public class Cube extends Block {

    Cube(Pixel origin, int length, int breadth, int height,Colour colour) {
        super(origin, length, breadth, height, colour);
    }

    List<Pixel> getPixels() {
        List<Pixel> pixels = new ArrayList<>();
        for (int x=0;x<length;x++){
            for (int y=0;y<breadth;y++){
                for (int z=0;z<height;z++){
                    pixels.add(new Pixel(x+origin.getX(),y+origin.getY(),z+origin.getZ(),colour));
                }
            }
        }
        return pixels;
    }
}
